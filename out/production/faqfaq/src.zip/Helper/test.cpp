#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;
void checkerror(){
	
	int i=1;
		for(i=0;i<=14;i++){
		string cp="copy .\\checkerror\\error_test_"+to_string(i)+".txt testfile.txt";
		system(cp.c_str());
		string run="java -jar faqfaq.jar";
		system(run.c_str());
		string cmd="fc /N .\\checkerror\\error_ans_"+to_string(i)+".txt error.txt > diff.txt";
		if(system(cmd.c_str())){
			cout<<"error "<<i<<'\n';
			system("pause");
		}
	}
	system("pause");
	for(i=1;i<=13;i++){
		string cp="copy .\\checkerror\\testfile"+to_string(i)+".txt testfile.txt";
		system(cp.c_str());
		string run="java -jar faqfaq.jar";
		system(run.c_str());
		string cmd="fc /N .\\checkerror\\output"+to_string(i)+".txt error.txt > diff.txt";
		if(system(cmd.c_str())){
			cout<<"error "<<i<<'\n';
			system("pause");
		}
	}

}
void checkparser(){
	int i,j;
		for(j=0;j<=2;j++){
		for(i=1;i<=30;i++){
			string zimu=string(1,j+'A');
			string cp="copy .\\testfiles-only\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			string cmd="fc /N .\\Syntaxanalysis\\"+zimu+"\\output"+to_string(i)+".txt output.txt > diff.txt";
			if(system(cmd.c_str())){
				cout<<"parseerror "<<i<<'\n';
				system("pause");
			}
		}
	}
}
int getCycle(){
	ifstream file;
	file.open("./InstructionStatistics.txt");
	string str;
	ostringstream sstr;
	sstr << file.rdbuf ();
	file.close();
	str=sstr.str ();
	string mark="FinalCycle : ";
	int pos=str.find(mark);
	pos+=mark.length();
	int num=0;
	while(str[pos]!='.'){
		num*=10;
		num+=str[pos]-'0';
		pos++;
	}
	return num;
}
void checkCycle(){
	int i,j;
	/*for(j=2;j>=0;j--){
		for(i=1;i<=30;i++){
			string zimu=string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle1=getCycle();
			run="java -jar pansy.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle2=getCycle(); 
			if(cycle2*1.5<cycle1){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}*/
	for(j=2;j>=0;j--){
		for(i=1;i<=30;i++){
			string zimu="2021_"+string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle1=getCycle();
			run="java -jar pansy.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle2=getCycle(); 
			if(cycle2>cycle1){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}
	for(j=2;j>=0;j--){
		for(i=1;i<=30;i++){
			string zimu=string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle1=getCycle();
			run="java -jar pansy.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			int cycle2=getCycle(); 
			if(cycle2>cycle1){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}
}
void checkmips2022(){
	int i,j;
	for(j=2;j>=0;j--){
		for(i=1;i<=30;i++){
			string zimu=string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\output"+to_string(i)+".txt output0.txt";
			system(cp.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			string cmd="fc /N out.txt output0.txt";
			if(system(cmd.c_str())){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}
}
void checkmips2021(){
		int i,j;
	for(j=2;j>=0;j--){
		for(i=1;i<=30;i++){
			string zimu="2021_"+string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\output"+to_string(i)+".txt output0.txt";
			system(cp.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			string cmd="fc /N out.txt output0.txt";
			if(system(cmd.c_str())){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}
}
void checkmips2023(){
		int i,j;
	for(j=2;j>=1;j--){
		for(i=1;i<=18;i++){
			string zimu=string(1,j+'A')+"2023";
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\output"+to_string(i)+".txt output0.txt";
			system(cp.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			string cmd="fc /N out.txt output0.txt";
			if(system(cmd.c_str())){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
	}
	j=0;
	for(i=1;i<=15;i++){
			string zimu=string(1,j+'A')+"2023";
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar faqfaq.jar";
			system(run.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\output"+to_string(i)+".txt output0.txt";
			system(cp.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			string cmd="fc /N out.txt output0.txt";
			if(system(cmd.c_str())){
				cout<<"error "<<zimu<<i<<'\n';
				system("pause");
			}
		}
}
void run(){
	int j=2;
	int i=7;
	string zimu=string(1,j+'A');
			string cp="copy .\\full\\"+zimu+"\\testfile"+to_string(i)+".txt testfile.txt";
			system(cp.c_str());
			string run="java -jar tql.jar";
			system(run.c_str());
			cp="copy .\\full\\"+zimu+"\\input"+to_string(i)+".txt input.txt";
			system(cp.c_str());
			cp="copy .\\full\\"+zimu+"\\output"+to_string(i)+".txt output0.txt";
			system(cp.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			cp="copy InstructionStatistics.txt cycle1.txt";
			system(cp.c_str());
			run="java -jar faqfaq.jar";
			system(run.c_str());
			run="java -jar mars.jar nc mips.txt <input.txt > out.txt";
			system(run.c_str());
			cp="copy InstructionStatistics.txt cycle2.txt";
			system(cp.c_str());
}
int main(){
	checkmips2023();
	checkmips2022();
	checkmips2021();
	//checkCycle();
	return 0;
}
