package SyntaxParser.OtherNode;

import SyntaxParser.ExpNode.EqExpNode;
import SyntaxParser.ExpNode.LAndExpNode;
import SyntaxParser.Node;

public class BTypeNode extends Node {

    public BTypeNode(int startLine, int endLine) {
        super(startLine, endLine);
    }
    public void checkError(){

    }
}
