package LlvmIr.Type;

public class FuncType extends LlvmType{
    public FuncType() {
    }
}
