package LlvmIr.Type;

public class BasicBlockType extends LlvmType{
    public BasicBlockType() {
    }
}
